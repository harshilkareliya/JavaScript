$(document).ready(function(){
    $("#menu").click(function(){
        $('nav').slideToggle(2000);
    });
});